package com.example.grueau_o_ble.UI

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.grueau_o_ble.R
import com.example.grueau_o_ble.UI.MainActivity.Companion.getStartIntent
import com.example.grueau_o_ble.databinding.ActivityMainBinding
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    companion object {
        fun getStartIntent(context: Context): Intent {
            return Intent(context, MainActivity::class.java)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // --> Indique que l'on utilise le ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        /*
        var  rvDevices: RecyclerView? = findViewById(R.id.rvDevices)
        var startScan: Button? = findViewById(R.id.startScan)
        var currentConnexion: Text?  = findViewById(R.id.currentConnexion)
        var disconnect: Button?  = findViewById(R.id.disconnect)
        var toggleLed: Button?  = findViewById(R.id.toggleLed)
        var ledStatus: Text?  = findViewById(R.id.ledStatus)
         */
        binding.buttscan.setOnClickListener {
            startActivity(ScanActivity.getStartIntent(this))
            finish()
        }
    }
}