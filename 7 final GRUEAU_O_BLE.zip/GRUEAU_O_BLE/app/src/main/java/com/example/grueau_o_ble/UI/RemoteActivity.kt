package com.example.grueau_o_ble.UI

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.grueau_o_ble.R
import com.example.grueau_o_ble.databinding.ActivityRemoteBinding
import com.example.grueau_o_ble.databinding.ActivityScanBinding

class RemoteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRemoteBinding

    companion object {
        fun getStartIntent(context: Context): Intent {
            return Intent(context, RemoteActivity::class.java)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_remote)

        //ScanActivity.Companion.toggleLed()
    }
}